# Beauty Studio — Customer Homepage

First-stage customer-facing homepage for the future Beauty Studio.

## Current scope
- Mobile-first responsive homepage
- Hero / brand introduction
- Services
- Work gallery placeholders
- Studio introduction
- Booking entry point
- Location / contact
- Mobile bottom navigation
- No external dependencies

## Deployment
This is a static site and can be deployed to GitHub Pages or Cloudflare Pages.

## Next planned layer
The placeholder content can later be connected to:
- Cloudflare Worker API
- D1 database
- R2 image/video storage
- Customer booking
- Studio CMS / admin panel
